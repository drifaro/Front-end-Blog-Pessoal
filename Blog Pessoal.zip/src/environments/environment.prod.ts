export const environment = {
  production: true,
  nome: '',
  token: '',
  id: 0,
  foto:''
};
